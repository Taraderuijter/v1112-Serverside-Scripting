<?php

	// Weet je wat.. hier heb je al mijn wachtwoorden
	$password1 = "f00bar";
	$password2 = "watDoeJeNou";
	$password3 = "yabadabbadoo";
	$password4 = "somebodySetUpUsTheBomb";
?>
